## Module <medical_lab_management>

#### 08.10.2020
#### Version 14.0.1.0.0
#### ADD
Initial Commit


