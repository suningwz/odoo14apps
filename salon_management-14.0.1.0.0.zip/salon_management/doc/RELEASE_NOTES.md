## Module <salon_management>

#### 20.10.2020
#### Version 14.0.1.0.0
##### ADD
- Initial Commit salon_management
