Employee Orientation v14
========================
This module developed to  manage employee orientation&training programs.


Configuration
=============
* No additional configurations needed

Company
-------
* `Cybrosys Techno Solutions <https://cybrosys.com/>`__

Credits
-------
* Developers: 	Anusha @cybrosys, odoo@cybrosys.com
 		Niyas V11 @cybrosys, odoo@cybrosys.com
		Kavya Raveendran V12 odoo@cybrosys.com
        Nimisha Murali V13 @cybrosys odoo@cybrosys.com
        Muhammed P V14 @cybrosys odoo@cybrosys.com


Contacts
--------
* Mail Contact : odoo@cybrosys.com
* Website : https://cybrosys.com

Bug Tracker
-----------
Bugs are tracked on GitHub Issues. In case of trouble, please check there if your issue has already been reported.

Maintainer
==========
.. image:: https://cybrosys.com/images/logo.png
   :target: https://cybrosys.com

This module is maintained by Cybrosys Technologies.

For support and more information, please visit `Our Website <https://cybrosys.com/>`__

Further information
===================
HTML Description: `<static/description/index.html>`__




