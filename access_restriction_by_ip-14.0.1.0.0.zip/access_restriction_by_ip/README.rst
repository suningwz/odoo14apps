Access Restriction By IP V14
============================

This module will restrict users access to his account from the specified IP only. If user access his
account from  non-specified IP, login will be restricted and a warning message will be displayed in
login page.

If no IP is specified for a user, then there will not be restriction by IP. He can access from any IP.


Credits
=======
Cybrosys Techno Solutions

Author
------
* Niyas Raphy <odoo@cybrosys.com>
* V14 Muhammad P <odoo@cybrosys.com>
