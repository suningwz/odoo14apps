## Module <automatic_payroll>

#### 14.11.2020
#### Version 14.0.1.0.0
##### ADD
- Initial Commit